import { Component, OnInit } from '@angular/core';

import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-user-home',
  templateUrl: './user-home.component.html',
  styleUrls: ['./user-home.component.scss']
})
export class UserHomeComponent implements OnInit {

  public userFormGroup : FormGroup;
  public myFormControl : FormControl;
  
  constructor() {
    this.myFormControl = new FormControl('25');
    this.userFormGroup = new FormGroup({
      firstName: new FormControl(),
      lastName: new FormControl(),
      pincode: new FormControl(),
      age: new FormControl(),
      contact: new FormControl(),
      address: new FormControl(),
      email: new FormControl(),
    })
  }

  ngOnInit(): void {
  }

}
